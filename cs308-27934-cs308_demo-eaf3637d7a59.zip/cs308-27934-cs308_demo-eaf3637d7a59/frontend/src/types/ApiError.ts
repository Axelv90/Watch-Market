export declare type ApiError = {
  message: string
  response: {
    data: {
      message: string
    }
  }
}
