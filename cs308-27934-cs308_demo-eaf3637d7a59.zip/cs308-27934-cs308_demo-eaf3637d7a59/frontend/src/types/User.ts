export type User = {
  isAdmin: any;
  _id: string;
  name: string;
  email: string;
  password: string;
};
