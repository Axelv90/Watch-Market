// The current database to use.
use('watchmarketts');

// Create a new document in the collection.
db.getCollection('users').insertOne({});
